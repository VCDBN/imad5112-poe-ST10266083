package com.varsitycollege.st10266083

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

//Reference:https://kotlinlang.org/docs/arrays.html
//Reference:https://www.geeksforgeeks.org/kotlin-list-average/
//Reference:https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/min.html
//Reference:https://developer.android.com/reference/android/widget/Button
//Reference:https://kotlinlang.org/docs/control-flow.html#for-loops
//Reference:https://youtu.be/2gljhNFKimk?si=JxS227CsnU4u5qNS

class Stats : AppCompatActivity()
{
    // Creating private variables
    private lateinit var EnterNumber: EditText
    private lateinit var resultTextView: TextView
    private lateinit var AddButton: Button
    private lateinit var ClearButton: Button
    private lateinit var AVGButton: Button
    private lateinit var MinMaxButton: Button
    private lateinit var StoredNums: TextView
    //The array to store 10 numbers
    private var enteredNumbers = IntArray(10)

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)
        initializeViews()

        // This button is to add the numbers.
        AddButton.setOnClickListener {
            addNumber()
        }
        // This button is to clear the list of numbers stored.
        ClearButton.setOnClickListener {
            clearNumbers()

        // This button is to calculate the average of the numbers
        }
        AVGButton.setOnClickListener {
            DisplayAverage()

        // This button is to display the min and max of the numbers.
        }
        MinMaxButton.setOnClickListener {
            DisplayMinMax()
        // This button stores the numbers in the array
        }
            StoredNums.setOnClickListener {
                storeNumbers()
        }
    }

    private fun initializeViews()
    {
        // Creating User interface with IDS.
        EnterNumber = findViewById(R.id.EnterNumber)
        resultTextView = findViewById(R.id.resultTextView)
        AddButton = findViewById(R.id.AddButton)
        ClearButton = findViewById(R.id.ClearButton)
        AVGButton = findViewById(R.id.AVGButton)
        MinMaxButton = findViewById(R.id.MinMaxButton)
        StoredNums = findViewById(R.id.StoredNums)
    }

    // Function to clear the numbers
    private fun clearNumbers()
    {
        // Set all elements in the array to 0 when clear button is pressed.
        enteredNumbers.fill(0)
        updateDisplayedNumbers()
    }

    // Function to Calculate and display the Average of the numbers
    private fun DisplayAverage()
    {
        if (enteredNumbers.any { it != 0 })
        {
            val sum = enteredNumbers.sum()
            val average = sum.toDouble() / enteredNumbers.count { it != 0 }
            displayResult("Average: $average")
        }
        else
        {
            displayResult("Please, enter numbers first.")
        }
    }

    // Function that calculates and displays the min and max of the numbers
    private fun DisplayMinMax()
    {
        if (enteredNumbers.any { it != 0 })
        {
            val min = enteredNumbers.filter { it != 0 }.minOrNull()
            val max = enteredNumbers.filter { it != 0 }.maxOrNull()
            displayResult("Min: $min, Max: $max")
        }
        else
        {
            displayResult("Please, Enter numbers first.")
        }
    }

    // Simple displays the results
    private fun displayResult(result: String)
    {
        resultTextView.text = result
    }

    private fun updateDisplayedNumbers()
    {
        StoredNums.text = enteredNumbers.filter { it != 0 }.joinToString(",")
    }

    private fun addNumber()
    {
        val number = EnterNumber.text.toString().toIntOrNull()
        if (number != null)
        {
            val index = enteredNumbers.indexOfFirst { it == 0 }
            if (index != -1)
            {
                enteredNumbers[index] = number
                updateDisplayedNumbers()
            }
            else
            {
                displayResult("Opps the Array is full. Remove some numbers first.")
            }
        }
        else
        {
            displayResult("Opps, Invalid input")
        }
    }

    private fun storeNumbers()
    {
        updateDisplayedNumbers()
    }
}