package com.varsitycollege.st10266083

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

//Reference:https://kotlinlang.org/docs/arrays.html
//Reference:https://www.geeksforgeeks.org/kotlin-list-average/
//Reference:https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/min.html
//Reference:https://developer.android.com/reference/android/widget/Button
//Reference:https://kotlinlang.org/docs/control-flow.html#for-loops
//Reference:https://youtu.be/2gljhNFKimk?si=JxS227CsnU4u5qNS

class Stats : AppCompatActivity() {

    // Creating private variables
    private lateinit var EnterNumber: EditText
    private lateinit var resultTextView: TextView
    private lateinit var AddButton: Button
    private lateinit var ClearButton: Button
    private lateinit var AVGButton: Button
    private lateinit var MinMaxButton: Button
    private lateinit var StoredNums: TextView
    private val MAX_NUMBERS = 10
    private var enteredNumbers = mutableListOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)
        initializeViews()

        // Enter numbers in text field.
        EnterNumber.setOnClickListener {
            addNumber()
        }

        // The button is to add the numbers.
        AddButton.setOnClickListener {
            addNumber()

        }
        // The button is to clear the list of numbers stored.
        ClearButton.setOnClickListener {
            clearNumbers()

        // The button is to calculate the average of the numbers
        }
        AVGButton.setOnClickListener {
            calculateAndDisplayAverage()

        // The button is to display the min and max of the numbers.
        }
        MinMaxButton.setOnClickListener {
            findAndDisplayMinMax()
        }
    }

    private fun initializeViews()
    {
        // Creating User interface with IDS.
        EnterNumber = findViewById(R.id.EnterNumber)
        resultTextView = findViewById(R.id.resultTextView)
        AddButton = findViewById(R.id.AddButton)
        ClearButton = findViewById(R.id.ClearButton)
        AVGButton = findViewById(R.id.AVGButton)
        MinMaxButton = findViewById(R.id.MinMaxButton)
        StoredNums = findViewById(R.id.StoredNums)
    }

    // Function to clear the numbers
    private fun clearNumbers()
    {
        enteredNumbers.clear()

    }

    // Function to Calculate and display the Average of the numbers
    private fun calculateAndDisplayAverage()
    {
        if (enteredNumbers.isNotEmpty())
        {
            val sum = enteredNumbers.sum()
            val average = sum.toDouble() / enteredNumbers.size
            displayResult("Average: $average")
        }
        else
        {
            displayResult("Please enter numbers first.")
        }
    }

    // Function that calculates and displays the min and max of the numbers
    private fun findAndDisplayMinMax()
    {
        if (enteredNumbers.isNotEmpty())
        {
            val min = enteredNumbers.minOrNull()
            val max = enteredNumbers.maxOrNull()
            displayResult("Min: $min, Max: $max")
        }
        else
        {
            displayResult("Please enter numbers first.")
        }
    }

    // Simple displays the results
    private fun displayResult(result: String) {
        resultTextView.text = result
    }

    // This function updates and displays the numbers you have entered in the memory text.
    private fun updateDisplayedNumbers() {
        StoredNums.text = enteredNumbers.joinToString(", ")
    }

    // This function lets you add numbers to the Textfields and you must have a max of 10 numbers added or and error message will come up.
    private fun addNumber()
    {
        if (enteredNumbers.size < MAX_NUMBERS)
        {
            val number = EnterNumber.text.toString().toIntOrNull()
            if (number != null)
            {
                enteredNumbers.add(number)

            }
            else
            {
                displayResult("Sorry, Invalid input")
            }
        }
        else
        {
            displayResult("Opps, maximum number limit reached")
        }
    }

}