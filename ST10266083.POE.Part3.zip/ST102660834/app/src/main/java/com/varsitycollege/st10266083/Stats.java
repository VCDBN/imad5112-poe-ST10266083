package com.varsitycollege.st10266083;

import android.app.Activity;

public class Stats extends Activity {
}
